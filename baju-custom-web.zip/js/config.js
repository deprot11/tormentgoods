/*
 * KONFIGURASI — satu-satunya file yang perlu Anda ubah.
 * Isi GAS_URL dengan URL Web App Apps Script (berakhiran /exec).
 * Contoh: 'https://script.google.com/macros/s/AKfycbx.../exec'
 */
const GAS_URL = 'TEMPEL_URL_EXEC_DI_SINI';
